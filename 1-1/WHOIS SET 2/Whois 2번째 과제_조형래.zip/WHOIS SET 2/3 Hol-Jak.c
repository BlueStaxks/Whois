#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
int main()
{
	char a;
	scanf("%c", &a);
	printf("%d", !((int)a % 2));
	return 0;
}