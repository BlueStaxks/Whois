#include <stdio.h>
int main()
{
	int a = 10, b = 100;
	printf("%d\n%d\n%d\n%d", a + b, a - b, a * 1000, b / 30);
	return 0;
}